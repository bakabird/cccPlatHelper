package com.qhhz.cocos.libandroid;


import android.app.Activity;
import android.app.Application;
import android.os.Build;
import android.view.Window;
import android.view.WindowManager;


/**
 * 启动套件
 */
public class Runkit {
    private static Runkit _me;

    public static Runkit get() {
        if (_me == null) {
            _me = new Runkit();
        }
        return _me;
    }

    private IRunkitAction $;

    private Runkit() {

    }

    public void Init(IRunkitAction runkitAction) {
        $ = runkitAction;
    }

    public Application app() {
        return $.getApp();
    }

    public Activity act() {
        return $.getAppActivity();
    }

    public void onConfirmProtocol() {
        $.onConfirmProtocol();
    }

    public IJSBWrapper jbw() {
        return $.getJSBWrapper();
    }

    public String spKey() {
        return $.getSharedPreferencesKey();
    }

    public void __internal__exitGame() {
        $.ExitGame();
    }

    public boolean isAgreeProtocol() {
        return SPStorage.get().getStr(SPStorage.ProtocolAgreementKey, "").equals("agree");
    }

    public void userAgreeProtocol() {
        SPStorage.get().setStr(SPStorage.ProtocolAgreementKey, "agree");
    }

    public static void FullScreen(Window window) {
        //屏幕适配核心 在AppActivity的onCreate添加  让画布扩充到刘海部分
        if (Build.VERSION.SDK_INT >= 28) {
            window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            window.setAttributes(lp);
        }
    }
}
