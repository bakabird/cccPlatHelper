package com.qhhz.cocos.libandroid;

public interface IVoidCallback {
    void callback();
}
