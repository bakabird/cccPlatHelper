package com.qhhz.cocos.libandroid;

public interface OnScriptEventListener {
    void onScriptEvent(String arg);
}
