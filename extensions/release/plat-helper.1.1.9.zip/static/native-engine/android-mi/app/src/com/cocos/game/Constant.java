package com.cocos.game;

public final class Constant {
    public final static String SPKEY_EVER_ADTIP_SHOW = "SPKEY_EVER_ADTIP_SHOW";
    public final static String SPKEY_NEXT_TRY_PERMISSION = "SPKEY_NEXT_TRY_PERMISSION";
}
