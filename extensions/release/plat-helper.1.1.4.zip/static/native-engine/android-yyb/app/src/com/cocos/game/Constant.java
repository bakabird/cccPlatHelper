package com.cocos.game;

public final class Constant {
    public static final String SPKEY_AD_PERMISSION_TIP = "SPKEY_AD_PERMISSION_TIP";
    public static final String SPKEY_AD_NEXTTRY_REQPERMISSION = "SPKEY_AD_NEXTTRY_REQPERMISSION";
}
