package com.qhhz.cocos.libandroid;

import android.view.ViewGroup;

public interface ISplashAdCallback {
    void reqAd(ViewGroup group);
}
