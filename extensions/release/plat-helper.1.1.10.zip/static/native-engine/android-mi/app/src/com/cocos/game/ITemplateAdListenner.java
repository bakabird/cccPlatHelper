package com.cocos.game;

public interface ITemplateAdListenner {
    void onError(String err);
    void onShow();
    void onClick();
    void onDismiss();
}
