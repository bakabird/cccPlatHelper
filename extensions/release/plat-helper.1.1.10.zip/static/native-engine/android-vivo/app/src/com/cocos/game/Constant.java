package com.cocos.game;

import com.LinesXFree.cocos.BuildConfig;

public final class Constant {
    public static final String APP_ID = BuildConfig.VIVO_APP_ID;
    public static final String AD_MEDIA_ID = BuildConfig.VIVO_AD_MEDIA_ID;
}
